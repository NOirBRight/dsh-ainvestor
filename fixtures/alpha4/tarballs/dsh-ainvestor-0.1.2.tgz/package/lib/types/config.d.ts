/**
 * Explicit backend ownership configuration for the AiInvestor plugin.
 *
 * @module dsh-ainvestor/config
 */
import type { StandardSchemaV1 } from '@standard-schema/spec';
/** Reserved child environment key used for authenticated backend readiness. */
export declare const INSTANCE_TOKEN_ENV = "DSH_AINVESTOR_INSTANCE_TOKEN";
/** Attach to a running backend. The plugin never starts or kills a process. */
export interface AttachSpec {
    readonly mode: 'attach';
    /** Backend origin, for example http://127.0.0.1:8766. */
    readonly baseUrl: string;
    /** HTTP request and response limits. */
    readonly http?: HttpConfig;
    /** Maximum duration of one readiness probe in milliseconds. */
    readonly probeTimeoutMs?: number;
}
/** Spawn and own one backend process from start through termination. */
export interface SpawnSpec {
    readonly mode: 'spawn';
    /** Backend origin used for readiness and tool requests. */
    readonly baseUrl: string;
    /** Explicit working directory for the child process. */
    readonly cwd: string;
    /** Explicit executable or command name. */
    readonly command: string;
    /** Explicit argument vector; an empty vector is valid. */
    readonly args: readonly string[];
    /** Optional configured environment; only safe launcher variables are forwarded and ambient variables are never inherited. */
    readonly env?: Readonly<Record<string, string>>;
    /** Maximum readiness wait in milliseconds. */
    readonly startupTimeoutMs?: number;
    /** Delay between readiness probes in milliseconds. */
    readonly probeIntervalMs?: number;
    /** Maximum duration of one readiness probe in milliseconds. */
    readonly probeTimeoutMs?: number;
    /** Grace period after SIGTERM in milliseconds. */
    readonly terminationGraceMs?: number;
    /** Maximum wait after SIGKILL in milliseconds. */
    readonly forceTerminationWaitMs?: number;
    /** Explicit log path; relative paths resolve from cwd. */
    readonly logPath: string;
    /** HTTP request and response limits. */
    readonly http?: HttpConfig;
}
/** Validated HTTP limits for backend requests. */
export interface HttpConfig {
    /** Maximum duration of one backend request in milliseconds. */
    readonly requestTimeoutMs?: number;
    /** Maximum backend response body size in bytes. */
    readonly maxResponseBytes?: number;
    /** Maximum time spent awaiting response-body cancellation in milliseconds. */
    readonly responseCancelTimeoutMs?: number;
}
/** Normalized HTTP limits used by every tool request. */
export interface ResolvedHttpConfig {
    readonly requestTimeoutMs: number;
    readonly maxResponseBytes: number;
    readonly responseCancelTimeoutMs: number;
}
/** Validated backend lifecycle ownership choice. */
export type BackendSpec = AttachSpec | SpawnSpec;
/** Backend specification with normalized origin and resolved lifecycle limits. */
export type ResolvedBackendSpec = (Omit<AttachSpec, 'baseUrl' | 'http' | 'probeTimeoutMs'> & {
    readonly baseUrl: string;
    readonly http: ResolvedHttpConfig;
    readonly probeTimeoutMs: number;
}) | (Omit<SpawnSpec, 'baseUrl' | 'http' | 'startupTimeoutMs' | 'probeIntervalMs' | 'probeTimeoutMs' | 'terminationGraceMs' | 'forceTerminationWaitMs' | 'logPath'> & {
    readonly baseUrl: string;
    readonly http: ResolvedHttpConfig;
    readonly startupTimeoutMs: number;
    readonly probeIntervalMs: number;
    readonly probeTimeoutMs: number;
    readonly terminationGraceMs: number;
    readonly forceTerminationWaitMs: number;
    readonly logPath: string;
});
/** Explicit default HTTP limits used when config omits the HTTP object. */
export declare const DEFAULT_HTTP_CONFIG: ResolvedHttpConfig;
/**
 * Standard Schema consumed by the official Cordis loader before plugin setup.
 * Programmatic callers should use resolveBackendSpec for the same check.
 */
export declare const Config: {
    '~standard': {
        version: 1;
        vendor: string;
        validate(value: unknown): StandardSchemaV1.Result<BackendSpec>;
    };
};
/** The resolved plugin configuration type. */
export type Config = BackendSpec;
/**
 * Validate and normalize raw plugin configuration.
 *
 * @param raw - Raw loader or programmatic configuration.
 * @returns A normalized explicit backend specification.
 * @throws {TypeError} If the mode, required fields, or field values are invalid.
 */
export declare function resolveBackendSpec(raw: unknown): ResolvedBackendSpec;
//# sourceMappingURL=config.d.ts.map