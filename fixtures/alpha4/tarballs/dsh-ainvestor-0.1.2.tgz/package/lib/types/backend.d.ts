/**
 * Explicit backend attachment and child-process ownership.
 *
 * @module dsh-ainvestor/backend
 */
import { type ResolvedBackendSpec } from './config.ts';
/** Startup ended because the owning lifecycle explicitly cancelled setup. */
export declare class StartupCancellationError extends Error {
    constructor(message: string);
}
/** A backend handle whose disposer reaches process quiescence. */
export interface BackendHandle {
    readonly mode: 'attached' | 'spawned';
    readonly pid?: number;
    dispose(): Promise<void>;
}
/**
 * Probe one backend health endpoint with caller cancellation and a local timeout.
 * When an expected token is provided, readiness also requires an exact response
 * header echo from the backend.
 *
 * @param baseUrl - Backend origin.
 * @param signal - Optional caller cancellation signal.
 * @param timeoutMs - Maximum probe duration and body-cancellation bound.
 * @param expectedToken - Optional per-spawn token required in the response.
 * @returns Whether the endpoint returned an HTTP success and token echo.
 */
export declare function probeLive(baseUrl: string, signal?: AbortSignal, timeoutMs?: number, expectedToken?: string): Promise<boolean>;
/**
 * Ensure the requested backend is reachable or owned by this plugin.
 * Spawn mode always creates one owned child and accepts readiness only after
 * the child echoes its private instance token.
 *
 * @param spec - Explicit attachment or spawn specification.
 * @param log - Lifecycle diagnostic sink.
 * @param signal - Setup cancellation signal.
 * @returns A handle with mode-specific ownership semantics.
 * @throws {Error} If attachment fails or an owned process cannot become ready.
 */
export declare function ensureBackend(spec: ResolvedBackendSpec, log: (line: string) => void, signal?: AbortSignal): Promise<BackendHandle>;
//# sourceMappingURL=backend.d.ts.map