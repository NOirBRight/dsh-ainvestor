/**
 * Read-only model tools backed by the AiInvestor HTTP API.
 *
 * @module dsh-ainvestor/tools
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import { type ResolvedHttpConfig } from './config.ts';
/**
 * Create a safe short diagnostic without stack frames or credential values.
 *
 * @param detail - Untrusted backend or transport detail.
 * @returns A bounded redacted diagnostic.
 */
declare function sanitizeDetail(detail: string): string;
/** Trim top-level arrays to their most recent entries and expose totals. */
declare function trimArrays(value: JsonValue, keep: number): JsonValue;
/**
 * Build the baseline read-only tool set.
 *
 * @param baseUrl - Validated backend origin.
 * @param http - Validated request timeout and response size limits.
 * @returns Exactly the baseline tool inventory.
 */
export declare function createTools(baseUrl: string, http?: ResolvedHttpConfig): ToolDefinition[];
/** The default response limit retained for focused module tests. */
export declare const MAX_BYTES: number;
/**
 * Invoke one backend request for focused module tests.
 *
 * @param baseUrl - Backend origin.
 * @param path - Endpoint path and query string.
 * @param http - Validated request timeout and response limits.
 * @param signal - Caller cancellation signal.
 * @returns A sanitized JSON result.
 */
export declare function _getJsonForTest(baseUrl: string, path: string, http?: ResolvedHttpConfig, signal?: AbortSignal): Promise<JsonValue>;
export { sanitizeDetail, trimArrays };
//# sourceMappingURL=tools.d.ts.map