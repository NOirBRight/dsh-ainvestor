/**
 * dsh-ainvestor — AiInvestor analysis copilot for DeepSeek Harness.
 *
 * LAB-only plugin with explicit attach/spawn backend ownership.
 *
 * @module dsh-ainvestor
 */
import type { Context } from '@deepseek-ai/cordis';
import type { BackendSpec } from './config.ts';
/** Cordis loader name. */
export declare const name = "dsh-ainvestor";
/** Services required by this host-only plugin. */
export declare const inject: readonly ["tools", "systemPrompt"];
/** Standard Schema consumed by the official Cordis loader. */
export declare const Config: {
    '~standard': {
        version: 1;
        vendor: string;
        validate(value: unknown): import("@standard-schema/spec").StandardSchemaV1.Result<BackendSpec>;
    };
};
/** Resolved plugin configuration. */
export type Config = BackendSpec;
/**
 * Register the backend-owned tools and methodology section with Cordis.
 * Startup is cancellable, and a startup failure rejects after reverse rollback
 * of every contribution acquired before the failure.
 *
 * @param ctx - Official Cordis plugin context.
 * @param rawConfig - Loader-resolved or programmatic plugin configuration.
 * @returns A promise that settles after backend startup and registration.
 * @throws {Error} If configuration, backend startup, registration, or rollback fails.
 */
export declare function apply(ctx: Context, rawConfig: unknown): Promise<void>;
//# sourceMappingURL=index.d.ts.map